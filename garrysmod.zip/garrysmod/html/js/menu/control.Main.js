
function ControllerMain( $scope, $element, $rootScope )
{
	$rootScope.ShowBack = false;
}
